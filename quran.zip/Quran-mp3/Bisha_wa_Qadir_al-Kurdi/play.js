document.getElementById("p1").addEventListener("click", function () {
  var audio = document.getElementById('q1');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p2").addEventListener("click", function () {
  var audio = document.getElementById('q2');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p3").addEventListener("click", function () {
  var audio = document.getElementById('q3');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p4").addEventListener("click", function () {
  var audio = document.getElementById('q4');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p8").addEventListener("click", function () {
  var audio = document.getElementById('q8');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p10").addEventListener("click", function () {
  var audio = document.getElementById('q10');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p12").addEventListener("click", function () {
  var audio = document.getElementById('q12');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p13").addEventListener("click", function () {
  var audio = document.getElementById('q13');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p14").addEventListener("click", function () {
  var audio = document.getElementById('q14');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p15").addEventListener("click", function () {
  var audio = document.getElementById('q15');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p16").addEventListener("click", function () {
  var audio = document.getElementById('q16');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p17").addEventListener("click", function () {
  var audio = document.getElementById('q17');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p18").addEventListener("click", function () {
  var audio = document.getElementById('q18');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p19").addEventListener("click", function () {
  var audio = document.getElementById('q19');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p20").addEventListener("click", function () {
  var audio = document.getElementById('q20');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p21").addEventListener("click", function () {
  var audio = document.getElementById('q21');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p23").addEventListener("click", function () {
  var audio = document.getElementById('q23');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p26").addEventListener("click", function () {
  var audio = document.getElementById('q26');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p27").addEventListener("click", function () {
  var audio = document.getElementById('q27');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p28").addEventListener("click", function () {
  var audio = document.getElementById('q28');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p29").addEventListener("click", function () {
  var audio = document.getElementById('q29');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p30").addEventListener("click", function () {
  var audio = document.getElementById('q30');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p31").addEventListener("click", function () {
  var audio = document.getElementById('q31');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p32").addEventListener("click", function () {
  var audio = document.getElementById('q32');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p36").addEventListener("click", function () {
  var audio = document.getElementById('q36');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p37").addEventListener("click", function () {
  var audio = document.getElementById('q37');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p38").addEventListener("click", function () {
  var audio = document.getElementById('q38');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p41").addEventListener("click", function () {
  var audio = document.getElementById('q41');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p44").addEventListener("click", function () {
  var audio = document.getElementById('q44');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p45").addEventListener("click", function () {
  var audio = document.getElementById('q45');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p46").addEventListener("click", function () {
  var audio = document.getElementById('q46');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p47").addEventListener("click", function () {
  var audio = document.getElementById('q47');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p48").addEventListener("click", function () {
  var audio = document.getElementById('q48');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p49").addEventListener("click", function () {
  var audio = document.getElementById('q49');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p50").addEventListener("click", function () {
  var audio = document.getElementById('q50');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p51").addEventListener("click", function () {
  var audio = document.getElementById('q51');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p52").addEventListener("click", function () {
  var audio = document.getElementById('q52');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p53").addEventListener("click", function () {
  var audio = document.getElementById('q53');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p54").addEventListener("click", function () {
  var audio = document.getElementById('q54');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p55").addEventListener("click", function () {
  var audio = document.getElementById('q55');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p56").addEventListener("click", function () {
  var audio = document.getElementById('q56');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p57").addEventListener("click", function () {
  var audio = document.getElementById('q57');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p58").addEventListener("click", function () {
  var audio = document.getElementById('q58');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p59").addEventListener("click", function () {
  var audio = document.getElementById('q59');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p60").addEventListener("click", function () {
  var audio = document.getElementById('q60');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p61").addEventListener("click", function () {
  var audio = document.getElementById('q61');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p62").addEventListener("click", function () {
  var audio = document.getElementById('q62');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p63").addEventListener("click", function () {
  var audio = document.getElementById('q63');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p64").addEventListener("click", function () {
  var audio = document.getElementById('q64');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p65").addEventListener("click", function () {
  var audio = document.getElementById('q65');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p66").addEventListener("click", function () {
  var audio = document.getElementById('q66');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p67").addEventListener("click", function () {
  var audio = document.getElementById('q67');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p68").addEventListener("click", function () {
  var audio = document.getElementById('q68');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p69").addEventListener("click", function () {
  var audio = document.getElementById('q69');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p70").addEventListener("click", function () {
  var audio = document.getElementById('q70');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p71").addEventListener("click", function () {
  var audio = document.getElementById('q71');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p72").addEventListener("click", function () {
  var audio = document.getElementById('q72');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p73").addEventListener("click", function () {
  var audio = document.getElementById('q73');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p74").addEventListener("click", function () {
  var audio = document.getElementById('q74');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p75").addEventListener("click", function () {
  var audio = document.getElementById('q75');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p76").addEventListener("click", function () {
  var audio = document.getElementById('q76');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p77").addEventListener("click", function () {
  var audio = document.getElementById('q77');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p78").addEventListener("click", function () {
  var audio = document.getElementById('q78');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p79").addEventListener("click", function () {
  var audio = document.getElementById('q79');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p80").addEventListener("click", function () {
  var audio = document.getElementById('q80');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p81").addEventListener("click", function () {
  var audio = document.getElementById('q81');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p82").addEventListener("click", function () {
  var audio = document.getElementById('q82');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p83").addEventListener("click", function () {
  var audio = document.getElementById('q83');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p84").addEventListener("click", function () {
  var audio = document.getElementById('q84');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p85").addEventListener("click", function () {
  var audio = document.getElementById('q85');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p86").addEventListener("click", function () {
  var audio = document.getElementById('q86');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p87").addEventListener("click", function () {
  var audio = document.getElementById('q87');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p88").addEventListener("click", function () {
  var audio = document.getElementById('q88');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p89").addEventListener("click", function () {
  var audio = document.getElementById('q89');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p90").addEventListener("click", function () {
  var audio = document.getElementById('q90');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p91").addEventListener("click", function () {
  var audio = document.getElementById('q91');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p92").addEventListener("click", function () {
  var audio = document.getElementById('q92');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p93").addEventListener("click", function () {
  var audio = document.getElementById('q93');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p94").addEventListener("click", function () {
  var audio = document.getElementById('q94');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p95").addEventListener("click", function () {
  var audio = document.getElementById('q95');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p96").addEventListener("click", function () {
  var audio = document.getElementById('q96');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p97").addEventListener("click", function () {
  var audio = document.getElementById('q97');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p98").addEventListener("click", function () {
  var audio = document.getElementById('q98');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p99").addEventListener("click", function () {
  var audio = document.getElementById('q99');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p100").addEventListener("click", function () {
  var audio = document.getElementById('q100');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p101").addEventListener("click", function () {
  var audio = document.getElementById('q101');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p102").addEventListener("click", function () {
  var audio = document.getElementById('q102');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p103").addEventListener("click", function () {
  var audio = document.getElementById('q103');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p104").addEventListener("click", function () {
  var audio = document.getElementById('q104');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p105").addEventListener("click", function () {
  var audio = document.getElementById('q105');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p106").addEventListener("click", function () {
  var audio = document.getElementById('q106');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p107").addEventListener("click", function () {
  var audio = document.getElementById('q107');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p108").addEventListener("click", function () {
  var audio = document.getElementById('q108');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p109").addEventListener("click", function () {
  var audio = document.getElementById('q109');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p110").addEventListener("click", function () {
  var audio = document.getElementById('q110');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p111").addEventListener("click", function () {
  var audio = document.getElementById('q111');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p112").addEventListener("click", function () {
  var audio = document.getElementById('q112');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p113").addEventListener("click", function () {
  var audio = document.getElementById('q113');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p114").addEventListener("click", function () {
  var audio = document.getElementById('q114');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

